﻿using System;
using System.Collections.Generic;
using System.Text;

namespace oop2_c_sharp_supermarket_management_windowsform
{
    class UserProvider
    {

        public static string username="";
        public static string role="";
        public static string gender="";
        public static int id=1;
        public static double salary=0; 
    }
}
